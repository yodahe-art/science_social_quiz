import 'package:flutter/material.dart';
import 'quiz_screen.dart';

class SubjectScreen extends StatelessWidget {
  final String section;
  final int grade;
  final Map<String, List<String>> subjects;

  SubjectScreen(this.section, this.grade, this.subjects);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Subject")),
      body: ListView.builder(
        itemCount: subjects.keys.length,
        itemBuilder: (context, index) {
          String subject = subjects.keys.elementAt(index);
          return ListTile(
            title: Text(subject),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => QuizScreen(subject),
              ),
            ),
          );
        },
      ),
    );
  }
}
