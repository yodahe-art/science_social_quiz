import 'package:flutter/material.dart';
import 'subject_screen.dart';

class GradeScreen extends StatelessWidget {
  final String section;

  GradeScreen(this.section);

  final Map<String, List<String>> naturalSubjects = {
    "Mathematics": [],
    "Biology": [],
    "Chemistry": [],
    "Physics": [],
    "English": [],
    "Aptitude": []
  };

  final Map<String, List<String>> socialSubjects = {
    "Mathematics": [],
    "History": [],
    "Geography": [],
    "Economics": [],
    "English": [],
    "Aptitude": []
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Grade")),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(4, (i) {
          int grade = i + 9;
          return ElevatedButton(
            onPressed: () {
              if (section == "Natural Science") {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SubjectScreen(section, grade, naturalSubjects),
                  ),
                );
              } else {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SubjectScreen(section, grade, socialSubjects),
                  ),
                );
              }
            },
            child: Text("Grade $grade"),
          );
        }),
      ),
    );
  }
}
