import 'package:flutter/material.dart';
import 'grade_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Choose Section")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => GradeScreen("Natural Science")),
              ),
              child: Text("Natural Science"),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => GradeScreen("Social Science")),
              ),
              child: Text("Social Science"),
            ),
          ],
        ),
      ),
    );
  }
}
