import 'package:flutter/material.dart';

class QuizScreen extends StatefulWidget {
  final String subject;

  QuizScreen(this.subject);

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int selectedOption = -1;

  final List<Map<String, dynamic>> questions = [
    {
      "question": "What is 2 + 2 * 2?",
      "options": ["4", "6", "2", "8"],
      "correct": 1,
      "explanation": "Multiplication comes before addition: 2 + (2*2) = 6"
    },
    {
      "question": "Which organelle is known as the powerhouse of the cell?",
      "options": ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"],
      "correct": 1,
      "explanation": "Mitochondria produce energy in the form of ATP."
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Quiz - \${widget.subject}")),
      body: ListView.builder(
        itemCount: questions.length,
        itemBuilder: (context, index) {
          var q = questions[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Q\${index + 1}: \${q["question"]}", style: TextStyle(fontSize: 18)),
                  ...List.generate(q["options"].length, (i) {
                    Color color = Colors.white;
                    if (selectedOption == i && i == q["correct"]) {
                      color = Colors.green.withOpacity(0.3);
                    } else if (selectedOption == i && i != q["correct"]) {
                      color = Colors.red.withOpacity(0.3);
                    }

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(color),
                          foregroundColor: MaterialStateProperty.all(Colors.black),
                        ),
                        onPressed: selectedOption == -1 ? () {
                          setState(() {
                            selectedOption = i;
                          });
                        } : null,
                        child: Text("\${i + 1}. \${q["options"][i]}"),
                      ),
                    );
                  }),
                  if (selectedOption != -1)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text("Explanation: \${q["explanation"]}", style: TextStyle(color: Colors.grey[700])),
                    )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
